/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

/**
 *
 * @author Kasun Gamage
 */
public class StudentController {

    public static int calcTotal(int tma1, int tma2, int tma3) {
        return tma1 + tma2 + tma3;
    }
}
